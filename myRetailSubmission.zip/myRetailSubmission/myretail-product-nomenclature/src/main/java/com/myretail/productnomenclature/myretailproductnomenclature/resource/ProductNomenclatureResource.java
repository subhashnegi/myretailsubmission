package com.myretail.productnomenclature.myretailproductnomenclature.resource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.myretail.productnomenclature.myretailproductnomenclature.resource.models.ProductLabel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.imageio.IIOException;
import java.io.IOException;

@RestController
@RequestMapping("/myretail/v1.0/productlabel")
public class ProductNomenclatureResource {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @GetMapping("/{prodId}")
    public ProductLabel getProductLabel(@PathVariable("prodId") Long productId){

        ProductLabel productLabel = new ProductLabel();
        String desc = "ProductName Not Found";
        try{
            String thirdPartyUrl = "https://redsky.target.com/v2/pdp/tcin/".concat(productId.toString()).concat("?excludes=taxonomy,price,promotion,bulk_ship,rating_and_review_reviews,rating_and_review_statistics,question_answer_statistics");
            String thirdpartyObject = restTemplate.getForObject(thirdPartyUrl, String.class);
            JsonNode jsonNode = objectMapper.readTree(thirdpartyObject);

            if(jsonNode!=null && jsonNode.get("product")!=null &&
                    jsonNode.get("product").get("item")!=null &&
                    jsonNode.get("product").get("item").get("product_description")!=null &&
                    jsonNode.get("product").get("item").get("product_description").get("title")!=null ){
                     desc = jsonNode.get("product").get("item").get("product_description").get("title").asText();
            }

            productLabel.setName(desc);

        }catch ( IOException io){

        }

       return productLabel;
    }

}
