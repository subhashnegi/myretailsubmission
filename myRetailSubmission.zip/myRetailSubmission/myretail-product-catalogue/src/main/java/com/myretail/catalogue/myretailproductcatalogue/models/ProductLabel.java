package com.myretail.catalogue.myretailproductcatalogue.models;

import java.io.Serializable;

public class ProductLabel implements Serializable {
    private String name;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public ProductLabel(String name) {
        this.name = name;
    }
    public  ProductLabel(){

    }
}
