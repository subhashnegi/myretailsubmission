package com.myretail.catalogue.myretailproductcatalogue.resource;

import com.myretail.catalogue.myretailproductcatalogue.models.Product;
import com.myretail.catalogue.myretailproductcatalogue.models.ProductLabel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/myretail/v1.0/product")
public class ProductResource {

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/{prodId}")
    public Product getProduct(@PathVariable("prodId") Long productId){

        //Invoke the PriceAPI
        String url = "http://myretail-product-price/myretail/v1.0/price/".concat(productId.toString());
        Product product = restTemplate.getForObject(url , Product.class);

        //Invoke the Product Name
        String getLabelUrl = "http://myretail-product-name/myretail/v1.0/productlabel/".concat(productId.toString());
        ProductLabel productLabel = restTemplate.getForObject(getLabelUrl, ProductLabel.class);

        product.setName(productLabel.getName());
        return product;
    }
}
