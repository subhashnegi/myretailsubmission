package com.myretail.price.myretailpricecatalogue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MyretailPriceCatalogueApplicationTests {

	@Test
	public void contextLoads() {
	}

}
