package com.myretail.price.myretailpricecatalogue.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;

@Document
public class ProductPrice implements Serializable {
    @Id
    private Long id;
    private CurrentPrice currentPrice;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CurrentPrice getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(CurrentPrice currentPrice) {
        this.currentPrice = currentPrice;
    }



    public ProductPrice(Long id, CurrentPrice currentPrice) {
        this.id = id;
        this.currentPrice = currentPrice;
    }

    public ProductPrice(){

    }

}
