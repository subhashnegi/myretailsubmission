package com.myretail.price.myretailpricecatalogue.resource;

import com.myretail.price.myretailpricecatalogue.document.ProductPrice;
import com.myretail.price.myretailpricecatalogue.repository.PriceRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/myretail/v1.0/price")
public class PriceResource {

    private PriceRepository priceRepository;

    public PriceResource(PriceRepository priceRepository) {
        this.priceRepository = priceRepository;
    }

    @GetMapping("/{prodId}")
    public ProductPrice getPrice(@PathVariable("prodId") long productId){

        return priceRepository.findById(productId);
    }

    @GetMapping("/all")
    public List<ProductPrice> getAllPrice(){
        return priceRepository.findAll();
    }

}
