package com.myretail.price.myretailpricecatalogue.repository;

import com.myretail.price.myretailpricecatalogue.document.ProductPrice;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PriceRepository extends MongoRepository<ProductPrice, Integer> {
    public ProductPrice findById(long id);
}
