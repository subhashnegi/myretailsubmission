package com.myretail.price.myretailpricecatalogue.config;

import com.myretail.price.myretailpricecatalogue.document.CurrentPrice;
import com.myretail.price.myretailpricecatalogue.document.ProductPrice;
import com.myretail.price.myretailpricecatalogue.repository.PriceRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@EnableMongoRepositories(basePackageClasses = PriceRepository.class)
@Configuration
public class PriceDBConfig {

    @Bean
    CommandLineRunner commandLineRunner(PriceRepository priceRepository){
        return strings -> {
            priceRepository.save(new ProductPrice(13860428L, new CurrentPrice(13.49,"USD")) );
            priceRepository.save(new ProductPrice(15117724L, new CurrentPrice(14.99,"USD")) );
            priceRepository.save(new ProductPrice(16696652L, new CurrentPrice(15.99,"USD")) );
            priceRepository.save(new ProductPrice(16752456L, new CurrentPrice(10.99,"USD")) );
        };
    }
}
